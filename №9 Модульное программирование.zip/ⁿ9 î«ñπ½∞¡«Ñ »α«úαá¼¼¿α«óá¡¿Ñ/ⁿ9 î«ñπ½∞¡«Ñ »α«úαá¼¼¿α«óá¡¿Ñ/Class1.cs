﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_Модульное_программирование
{
    class Class1
    {
            public static double MaxOfThree(double a, double b)
             {
                     double x = Math.Cos((a + b) / 2);
                     double y = Math.Sin(a + b);
                     double z = a / b;

                    return Math.Max(x, Math.Max(y, z));
             }
    }
}
