﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_Модульное_программирование
{
    class Class2
    {
 
            public static int CountOccurrences(int[] array, int n)
            {
                int count = 0;
                foreach (int element in array)
                {
                    if (element == n)
                    {
                        count++;
                    }
                }
                return count;
            }

            public static void FindMaxAndCount(int[] array, out int maxElement)
            {
                if (array == null || array.Length == 0)
                {
                    maxElement = 0;
                    return;
                }

                maxElement = array[0];
                int count = 1;

                for (int i = 1; i < array.Length; i++)
                {
                    if (array[i] > maxElement)
                    {
                        maxElement = array[i];
                        count = 1; // Reset count for new maximum
                    }
                    else if (array[i] == maxElement)
                    {
                        count++;
                    }
                }

                Console.WriteLine($"Maximum element: {maxElement}, Count: {count}");
            }


            public static int SumFirstNElements(int[] array, int n)
            {
                int sum = 0;
                for (int i = 0; i < Math.Min(n, array.Length); i++)
                {
                    sum += array[i];
                }
                return sum;
            }
        public static int CountCharInSequence(string sequence, char target)
        {
            if (string.IsNullOrEmpty(sequence))
            {
                return 0; // Или выбросить исключение, если пустая строка не допустима
            }

            int count = 0;
            foreach (char c in sequence)
            {
                if (c == target)
                {
                    count++;
                }
            }
            return count;
        }
    }
    }



