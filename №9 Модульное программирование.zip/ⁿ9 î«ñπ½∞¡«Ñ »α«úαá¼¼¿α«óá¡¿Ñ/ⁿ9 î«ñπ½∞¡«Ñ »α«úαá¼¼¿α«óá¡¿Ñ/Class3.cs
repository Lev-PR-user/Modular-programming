﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_Модульное_программирование
{
    class Class3
    {
            public static void ReplaceDiagonalWithZeros(int[,] matrix)
            {
                int rows = matrix.GetLength(0);
                int cols = matrix.GetLength(1);

                for (int i = 0; i < Math.Min(rows, cols); i++)
                {
                    matrix[i, i] = 0;
                }
            }

            public static void ReplaceNegativeWithOnes(int[,] matrix)
            {
                int rows = matrix.GetLength(0);
                int cols = matrix.GetLength(1);

                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < cols; j++)
                    {
                        if (matrix[i, j] < 0)
                        {
                            matrix[i, j] = 1;
                        }
                    }
                }
            }

            public static int SumOfRowMinimums(int[,] matrix)
            {
                int rows = matrix.GetLength(0);
                int cols = matrix.GetLength(1);
                int sum = 0;

                for (int i = 0; i < rows; i++)
                {
                    int min = matrix[i, 0];
                    for (int j = 1; j < cols; j++)
                    {
                        if (matrix[i, j] < min)
                        {
                            min = matrix[i, j];
                        }
                    }
                    sum += min;
                }
                return sum;
            }
        }
    }

