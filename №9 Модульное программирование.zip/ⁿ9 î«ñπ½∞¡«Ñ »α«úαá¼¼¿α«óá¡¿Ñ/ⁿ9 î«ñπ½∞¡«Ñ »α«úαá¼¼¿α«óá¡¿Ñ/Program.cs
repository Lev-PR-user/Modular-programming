﻿using System;
using _9_Модульное_программирование;


namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Выберите номер задания (4, 9, 10, 11, 16, 17, 18, 21, 22, 23, 24), или exit:");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "4":
                        Console.WriteLine("Введите a:");
                        double a = double.Parse(Console.ReadLine());
                        Console.WriteLine("Введите b:");
                        double b = double.Parse(Console.ReadLine());
                        double max = Class1.MaxOfThree(a, b);
                        Console.WriteLine($"Максимум из трех выражений: {max}");
                        break;

                    case "9":
                        Console.WriteLine("Введите массив целых чисел (через пробел):");
                        string[] input = Console.ReadLine().Split(' ');
                        int[] array = Array.ConvertAll(input, int.Parse);
                        Console.WriteLine("Введите число для поиска:");
                        int n = int.Parse(Console.ReadLine());
                        int count = Class2.CountOccurrences(array, n);
                        Console.WriteLine($"Число {n} встречается в массиве {count} раз.");
                        break;

                    case "10":
                        Console.WriteLine("Введите строку:");
                        string sequence = Console.ReadLine();
                        Console.WriteLine("Введите символ для поиска:");
                        char target = Console.ReadKey().KeyChar;
                        Console.WriteLine();
                        int charCount = Class2.CountCharInSequence(sequence, target);
                        Console.WriteLine($"Символ '{target}' встречается в строке {charCount} раз.");
                        break;

                    case "11":
                        Console.WriteLine("Введите массив целых чисел (через пробел):");
                        string[] inputArray = Console.ReadLine().Split(' ');
                        int[] intArray = Array.ConvertAll(inputArray, int.Parse);

                        Class2.FindMaxAndCount(intArray, out int maxElement);

                        break;

                    case "16":
                        Console.WriteLine("Введите размерность матрицы:");
                        int size = int.Parse(Console.ReadLine());
                        int[,] matrix716 = new int[size, size];
                        Console.WriteLine("Введите элементы матрицы:");
                        for (int i = 0; i < size; i++)
                        {
                            string[] rowElements = Console.ReadLine().Split(' ');
                            for (int j = 0; j < size; j++)
                            {
                                matrix716[i, j] = int.Parse(rowElements[j]);
                            }
                        }
                        Class3.ReplaceDiagonalWithZeros(matrix716);

                        Console.WriteLine("Матрица с замененной диагональю:");
                        for (int i = 0; i < size; i++)
                        {
                            for (int j = 0; j < size; j++)
                            {
                                Console.Write(matrix716[i, j] + " ");
                            }
                            Console.WriteLine();
                        }
                        break;

                    case "17":
                        Console.WriteLine("Введите размерность матрицы:");
                        int size717 = int.Parse(Console.ReadLine());
                        int[,] matrix717 = new int[size717, size717];
                        Console.WriteLine("Введите элементы матрицы:");
                        for (int i = 0; i < size717; i++)
                        {
                            string[] rowElements = Console.ReadLine().Split(' ');
                            for (int j = 0; j < size717; j++)
                            {
                                matrix717[i, j] = int.Parse(rowElements[j]);
                            }
                        }
                        Class3.ReplaceNegativeWithOnes(matrix717);

                        Console.WriteLine("Матрица с замененными отрицательными числами:");
                        for (int i = 0; i < size717; i++)
                        {
                            for (int j = 0; j < size717; j++)
                            {
                                Console.Write(matrix717[i, j] + " ");
                            }
                            Console.WriteLine();
                        }
                        break;

                    case "18":
                        Console.WriteLine("Введите количество строк матрицы:");
                        int rows = int.Parse(Console.ReadLine());
                        Console.WriteLine("Введите количество столбцов матрицы:");
                        int cols = int.Parse(Console.ReadLine());
                        int[,] matrix718 = new int[rows, cols];

                        Console.WriteLine("Введите элементы матрицы:");
                        for (int i = 0; i < rows; i++)
                        {
                            string[] rowElements = Console.ReadLine().Split(' ');
                            for (int j = 0; j < cols; j++)
                            {
                                matrix718[i, j] = int.Parse(rowElements[j]);
                            }
                        }

                        int sumOfMinimums = Class3.SumOfRowMinimums(matrix718);
                        Console.WriteLine($"Сумма минимальных элементов по строкам: {sumOfMinimums}");
                        break;

                    case "21":
                        Console.WriteLine("Введите строку:");
                        string inputString = Console.ReadLine();
                        string reversedString = Class4.ReverseString(inputString);
                        Console.WriteLine($"Строка в обратном порядке: {reversedString}");
                        break;

                    case "22":
                        Console.WriteLine("Введите строку:");
                        string originalString = Console.ReadLine();
                        string prefixedString = Class4.AddPrefix(originalString);
                        Console.WriteLine($"Строка с префиксом: {prefixedString}");
                        break;

                    case "23":
                        Console.WriteLine("Введите символ:");
                        char symbol = Console.ReadKey().KeyChar;
                        Console.WriteLine();
                        Console.WriteLine("Введите количество повторений:");
                        int k = int.Parse(Console.ReadLine());
                        string repeatedString = Class4.CreateStringFromChar(symbol, k);
                        Console.WriteLine($"Строка из {k} символов '{symbol}': {repeatedString}");
                        break;

                    case "24":
                        Console.WriteLine("Введите массив целых чисел (через пробел):");
                        string[] input724 = Console.ReadLine().Split(' ');
                        int[] array724 = Array.ConvertAll(input724, int.Parse);
                        Console.WriteLine("Введите количество первых элементов для суммирования:");
                        int n724 = int.Parse(Console.ReadLine());
                        int sum724 = Class2.SumFirstNElements(array724, n724);
                        Console.WriteLine($"Сумма первых {n724} элементов массива: {sum724}");
                        break;

                    case "exit":
                        return;

                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }
            }
        }
    }
}