﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_Модульное_программирование
{
    class Class4
    {     
            public static string ReverseString(string input)
            {
                return new string(input.ToCharArray().Reverse().ToArray());
            }

            public static string AddPrefix(string input)
            {
                return "++++-----" + input;
            }

            public static string CreateStringFromChar(char symbol, int k)
            {
                return new string(symbol, k);
            }
        }
    }

